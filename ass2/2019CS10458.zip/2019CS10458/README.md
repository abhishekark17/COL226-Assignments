follow these steps:
`ml-lex ass2.lex`
`ml-yacc ass2.yacc`
`sml loader.sml`

for running the file use `insertFileName <filename>`

